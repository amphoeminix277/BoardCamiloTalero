// importamos los modulos  express para crear el servidor y mongoose para MongoDB
const express = require("express");
const mongoose = require("mongoose");

// importamos routes
const User = require("./routes/user");

// creamos variable principal que ejecuta nuestra app
const app = express();
// que usos tiene mi app
app.use(express.json());
app.use("/api/user/", User)

// creamos variable del puerto de nuestro server sea hosting o local
const port = process.env.PORT || 3001; 

// escuchando puerto y desplegando servidor 
app.listen(port, () => console.log("Servidor ejecutando en puerto: " + port));
// http://localhost:3001/api/user/registerUser  

// conexion con MongoDB
mongoose.connect("mongodb://localhost:27017/sbprojectbd", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
    useCreateIndex: true
})
.then(() => console.log("Conexion con MongoDB: ON"))
.catch((error) => console.log("Error al conectar al conectar con MongoDB:", error));