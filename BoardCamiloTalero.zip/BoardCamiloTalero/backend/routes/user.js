// importamos los modulos necesarios 
const express = require("express");
const router = express.Router();
const User = require("../models/user")
const bcrypt = require("bcrypt")

// registrar usuario - async await POST
router.post("/resgisterUser", async (req, res) =>{
    // validamos que el correo existe en BD
    let user = await User.findOne({email: req.body.email})
    // si el usuario ya existe mostramos un mensaje 
    if (user) return res.status(400).send("El usuario ya existe");
    // encriptamos el pass
    const hash = await bcrypt.hash(req.body.password, 10)
    // guardamos los datos del usuario 
    user = new User({
        name: req.body.name,
        email: req.body.email,
        password: hash,
    })
    const result = await user.save();
    if (result) {
        // jwt
        const jwtToken = user.generateJWT()
        res.status(200).send({jwtToken})
    } else {
return res.status(400).send("No se puede registrar el usuario");
    }
});

//exportamos 
module.exports = router;